# Project: React Accelerator
## status: work in progress
The accelerator and this README are works in progress and subject to change.

# Introduction: 

The react accelerator is a common starting point for WBA web app frontends created with React.  The purpose of the accelerator is for all future react projects to share common core elements for better support in the long run and for all WBA react apps to meet WBA's standards.

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Getting started

- Step 1:  Fork the repository dai-skeleton-react into the new project
- Step 2:  Update the following files with the new project information
    -  public/index.html
    -  public/manifest.json
    -  package.json
    -  package-lock.json
    -  nginx/nginx.conf
    -  dockerfile
    -  docker-compose.yml
    -  cicd/config/prod.yaml
    -  cicd/config/prodfix.yaml
    -  cicd/config/qa.yaml
- Step 3: run npm install from the command-line of the project directory that contains the forked code.
- Step 4: remove standIn.js from src/App.js and replace with your project
- Step 5: Update the README.md file in the new project 

# standardized dependencies included in the React Accelerator

-  UI library:           react-bootstrap     [The documentation can be found here](https://react-bootstrap.github.io/)
-  Testing library:      Jest                [the documentation can be found here](https://jestjs.io/docs/tutorial-react)
-  Global state manager: Zustand             [the documentation can be found here](https://docs.pmnd.rs/zustand/introduction)

- TypeScript and react-router are included and configured but not required.

# Notes on the standardized dependencies

Global state manager zustand is a light weight hooks based state-manager.  

To use a global state, add it in the store at src/store/store.js

    example: 

    in side of the functional component useStore add two lines for each state

          isLoading:true,
          setIsLoading: (bool) => set(() => {isLoading: bool})

    to access the global state add to the component file
          import useStore from '../store/store.js

    inside of the component that needs to access the global state.

          const [isLoading, setIsLoading] = useStore()

    then use the global State the same way as useState

# WBA digital style 
UI Library bootstrap:

WBA has a published set of standards for the companies digital presence.  These standards can be found here:
http://m-int1.walgreens.com/livestyleguide/walgreens.com/v4.0_static/  *(Note you must be inside of the WBA domain to access)*

WBA's approved palette is included in the app.css as variables.  These variables are accessible in local css files.

  - --wagRed: #e62600;
  - --cream: #f5f5f0;
  - --navyBlue: #323264;
  - --skyBlue: #c2e8ff;
  - --ruby: #aa0a0a;
  - --teal: #0082aa;
  - --demin: #284b9b;
  - --sienna: #dc7846;
  - --liteCream: #f9f9f6;
  - --alertGreen: #00853e;
  - --alertYellow: #fff284;
  - --alertYellow-aa: #bc5724;
  - --seassonalRed: #d91734;
  - --seassonalGreen: #00853e;
  - --seassonalPink: #e60572;
  - --seassonalYellow: #fff284;
  - --seassonalOrange: #ed8b00;

Example of variable as color in css:
color: var(--WagRed); 
this will set the font color to WBA's official shade of red

Additionally a set of custom hooks is include.  These are included for convenience and are NOT required.  Details on the use of the hooks are included in the individual hook files.

example:

src/hooks/useAsync.js

includes at the end:
`
// A hook for simplifying management of Async functions
// the hook takes two parameters 
//  1st the aysnc function you want to use
//  2nd a boolean. true if you want it to execute the function immediately / false if you want to invoke it 
//
// the hook returns
//  executeAsync : a callback function to run your Async functions
//  status : gives the current status of the Async function [idle, pending, success, error]
//  value : the response from the Async function passed to the hook.  it will be null unless a successful response is received
//  error : any errors returned by the Async function passed to the hook
//
//
// example: 
// const { executeAsync, status, value, error } = useAsync(myFunction, false);
//
//    return (
//    <div>
//    {status === "idle" && <div>Start your journey by clicking a button</div>}
//    {status === "success" && <div>{value}</div>}
//    {status === "error" && <div>{error}</div>}
//    <button onClick={execute} disabled={status === "pending"}>
//      {status !== "pending" ? "Click me" : "Loading..."}
//    </button>
// </div>
//  );`

src/hooks/useGridTable.js

includes at the end:
`
// A hook for simplifying creation of tables by using ag react grid
// the hook takes three parameters can be found here :
// 1. list of columns
// 2. data for the table
// 3. a function for creating new row
//
// the hook returns
// table content to be displayed along with create row button
//
//
// example: 
// const TableContent = UseGridTable({
//    columns:[{ field: "make"}, { field: "model" }, { field: "price" }],
//    data: [{ make: "Toyota", model: "Celica", price: 35000 }, { make: "Ford", model: "Mondeo", price: 32000 }],
//    onAddRow: ()=>{},
// });
//
//    return (
//    <div>
//       <div><button onClick={onAddRow}>Add Row</button></div>
//       {TableContent}
//    </div>
//  );`


src/hooks/useAuthLogin.js

includes at the end:
`
// A hook for simplifying management of auth login
// the hook has list of parameters can be found here :
// https://www.npmjs.com/package/react-simple-oauth2-login
//
// the hook returns
// redirect url with response type and code and scope
//
//
// example: 
// const AuthLogin = useAuthLogin({
//      clientId:'123caer2342',
//    responseType: 'code',
//    authorizeUri: http://foo.test/authorize,
//    redirectUri: http://foo.test/auth/OAuth2,
//    onSuccess: ()=>{},
//    onFailure: ()=>{},
});
//
//    return (
//    <div>
//    {AuthLogin}
// </div>
//  );`

src/hooks/useDebounce.js

includes at the end:
`
// A hook for simplifying search 
// the hook takes two parameters 
//  1st the state variable we are going to use in search input.
//  2nd a timeout limit in milliseconds.
//
// the hook returns
//  callback : delayed till user types value in input search field.
//
//
// example: 
// const [searchTerm, setSearchTerm] = useState('');
// const debounceValue = UseDebounce(searchTerm, 500);
// useEffect(() => {
//    action to be done after delay.
// }, [debounceValue])
//
//    return (
//    <div>
//    <input value={searchTerm}>
// </div>
//  );`
### React-Query
React Query simplifies fetching, caching and updating data without a global state dependency. Using the useQuery-hook form React Query library we can handle API transactions. useQuery hook accepts two params -
1) The cache key
2) Function that returns a promise that resolves the data or throws an error.
```
const { data: userProfile, isLoading: isUserProfileLoading } = useQuery('UserProfile', getUserProfile);
```
for more details please check @ https://www.npmjs.com/package/react-query


//below all common components built on react-bootstrap so any props related information check react-bootstrap lib.
src/core/alert-box/alert-box.js
`
// example: 
// <AlertBox variant={'primary'}>This is Primary AlertBox</AlertBox>
//  );`

src/core/button/button.js
`
// example: 
// <TypesExample varient="primary" size="lg"> Primary </TypesExample>
`

src/core/card/card.js
`
// example: 
//  <Card cardStyles={{ width: '15rem' }} cardContent={() => <p>Card content</p>} />
`

src/core/drop-down-menu/drop-down-menu.js
`
// example: 
<DropDownMenuList
dropdownBtn={{ variant: 'primary', title: 'Primary Dropdown' }}
dropdownList={[
  { key: 0, type: 'item', label: 'Apple' },
  { key: 1, type: 'item', label: 'Banana' },
  { key: 2, type: 'divider', label: null },
  { key: 3, type: 'item', label: 'React' }
]}
/>`

src/core/footer/footer.js
`
// example: 
<Footer />`

src/core/header/header.js
`
// example: 
<Header headerTitle={'Header'} headerLink="#header" navList={[ { label: 'Home', href: '#action1' },{ label: 'Login', href: '#action2' }]} />
`

src/core/sidebar/sidebar.js
`
// example: 
 <SidebarLayout
        title="Sidebar"
        sidebarContent={sidebarContent}
        sidebarProps={{ docked: true, open: true }}
      >
      <div>content</div>
</SidebarLayout>
`


src/core/table-container/table-container.js
`
// example: 
<TableContainer
            tableConfig={{ striped: true, bordered: true, hover: true }}
            columns={[
              { id: 1, title: '#' },
              { id: 2, title: 'First Name' },
              { id: 3, title: 'Last Name' },
              { id: 4, title: 'Username' }
            ]}
            rows={[
              {
                id: 1,
                firstName: 'Apple',
                lastName: 'fruits',
                userName: 'a@fruits'
              },
              {
                id: 1,
                firstName: 'Mango',
                lastName: 'fruits',
                userName: 'm@fruits'
              }
            ]}
          />
`

src/core/toast-box/toast-box.js
`
// example: 
<ToastBox
      header={<div>Header</div>}
      body={'Hello, world! This is a toast message'}
/>

`