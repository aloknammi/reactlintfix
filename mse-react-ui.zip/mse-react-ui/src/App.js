import React from 'react'
import './App.css';
import RouterComponent from './Router';

const App = () => {
  return (
    <div className="App">
      {/* <header className="App-header">
        <p>Edit <code>src/App.js</code> and save to reload.</p>
      </header> */}
      <RouterComponent />
    </div>
  );
}

export default App;
