import React from 'react';
import { cleanup, render, waitFor } from '@testing-library/react';
import DropDownMenuList from '../../core/drop-down-menu/drop-down-menu';

describe('Dropdown Menu', () => {
  const list = [
    { key: '0', type: 'item', label: 'Apple' },
    { key: '1', type: 'item', label: 'Banana' },
    { key: '2', type: 'divider', label: null },
    { key: '3', type: 'item', label: 'React' }
  ];

  beforeEach(() => {
    cleanup();
  });

  it('should able to render app', () => {
    const app = render(
      <DropDownMenuList
        dropdownBtn={{
          variant: 'primary',
          title: 'Primary Dropdown'
        }}
        dropdownList={list}
      />
    );
    expect(app).toBeTruthy();
  });

  it('should able to render Drop down menu list with menu item', () => {
    const app = render(
      <DropDownMenuList
        dropdownBtn={{
          variant: 'primary',
          title: 'Primary Dropdown',
          defaultShow: true
        }}
        dropdownList={list}
      />
    );
    waitFor(() => {
      expect(
        app.container.querySelectorAll('#dropdown-list-item').length
      ).toEqual(list.length - 1);
    });
  });

  it('should render app with no list item when type id not matched', () => {
    const app = render(
      <DropDownMenuList
        dropdownBtn={{
          variant: 'primary',
          title: 'Primary Dropdown',
          defaultShow: true
        }}
        dropdownList={[{ type: 'data' }]}
      />
    );
    waitFor(() => {
      expect(
        app.container.querySelectorAll('#dropdown-list-item').length
      ).toEqual(0);
    });
  });
});
