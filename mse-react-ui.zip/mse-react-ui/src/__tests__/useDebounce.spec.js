import {
  cleanup,
  renderHook
} from '@testing-library/react';
import UseDebounce from '../hooks/useDebounce';

jest.mock('react', () => ({
  ...jest.requireActual('react'),
  useState: jest.fn()
}))
// eslint-disable-next-line import/first
import { useState } from 'react';

describe('useAuthLogin', () => {
  beforeEach(() => {
    useState.mockImplementation(jest.requireActual('react').useState);
  })
  afterEach(() => {
    cleanup();
  });

  it('should able to render hooks', () => {
    const app = renderHook(() => UseDebounce('text', 500));
    expect(app).toBeTruthy();
  });
});
