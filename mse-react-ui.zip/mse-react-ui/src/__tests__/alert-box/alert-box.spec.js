import React from 'react';
import { cleanup, render } from '@testing-library/react';
import AlertBox from '../../core/alert-box/alert-box';

describe('Alert Box', () => {
  beforeEach(() => {
    cleanup();
  });

  it('should able to render alert box', () => {
    const app = render(
      <AlertBox variant={'primary'}>This is Primary AlertBox</AlertBox>
    );
    expect(app).toBeTruthy();
    expect(app.queryByText(/This is Primary AlertBox/i)).toBeTruthy();
  });
});
