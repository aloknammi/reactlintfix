import React from "react";
import {
    cleanup,
    fireEvent,
    render,
    waitFor
  } from '@testing-library/react';
import UseGridTable from "../hooks/useGridTable";

  describe('useGridTable', () => {
    const onAddRowSpy = jest.fn();
    const config = {
      columns: [{ field: "make" }, { field: "model" }, { field: "price" }],
      data: [{ make: "Toyota", model: "Celica", price: 35000 }, { make: "Ford", model: "Mondeo", price: 32000 }],
      onAddRow: onAddRowSpy
    };

    afterEach(() => {
      cleanup();
    });
    beforeEach(() => {
      const mockedCallback = jest.fn()
      mockedCallback.mockReturnValue({});
      onAddRowSpy.mockReset();
    });

    it('should able to render hooks', () => {
      const app = render(
        <UseGridTable {...config} />
      )
      expect(app).toBeTruthy();
    });

    it('should able to render with add row button', () => {
      const app = render(
        <UseGridTable {...config} />
      )
      expect(app.getByText('Add Row')).toBeTruthy();
    });

    it('should able to render without add row button when onAddRow not passed as param', () => {
      const app = render(
        <UseGridTable columns={[{ field: "make" }, { field: "model" }, { field: "price" }]} data={[{ make: "Toyota", model: "Celica", price: 35000 }, { make: "Ford", model: "Mondeo", price: 32000 }] } />
      )
      // const app = render(UseGridTable({ }));
      expect(app.queryByText('Add Row')).toBeFalsy();
    });

    it('should able to add a row when add row button clicked', () => {
      const app = render(
        <UseGridTable {...config} />
      )
      const addRowBUtton = app.getByText('Add Row');
      fireEvent.click(addRowBUtton);
      waitFor(() => {
        expect(onAddRowSpy).toBeCalledTimes(1);
      });
    });
  });
