import React from 'react';
import {render} from '@testing-library/react';
import RouterComponent from '../../Router';

test('renders learn react link', () => {
  const app = render(<RouterComponent />);
  expect(app).toBeTruthy();
});
