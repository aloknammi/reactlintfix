import React from 'react';
import { cleanup, render } from '@testing-library/react';
import Card from '../../core/card/card';

describe('Card', () => {
  beforeEach(() => {
    cleanup();
  });

  it('should able to render Card', () => {
    const app = render(
      <Card
        cardStyles={{ width: '15rem' }}
        cardContent={() => <p>Card content</p>}
      />
    );
    expect(app).toBeTruthy();
    expect(app.queryByText(/Card content/i)).toBeTruthy();
  });
});
