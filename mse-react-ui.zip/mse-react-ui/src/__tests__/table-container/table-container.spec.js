import React from 'react';
import { cleanup, render } from '@testing-library/react';
import TableContainer from '../../core/table-container/table-container';

describe('TableContainer', () => {
  beforeEach(() => {
    cleanup();
  });

  it('should able to render app', () => {
    const app = render(
      <TableContainer
        tableConfig={{ striped: true, bordered: true, hover: true }}
        columns={[
          { id: '1', title: '#' },
          { id: '2', title: 'First Name' },
          { id: '3', title: 'Last Name' },
          { id: '4', title: 'Username' }
        ]}
        rows={[
          {
            id: '1',
            firstName: 'Apple',
            lastName: 'fruits',
            userName: 'a@fruits'
          },
          {
            id: '2',
            firstName: 'Mango',
            lastName: 'fruits',
            userName: 'm@fruits'
          }
        ]}
      />
    );
    expect(app).toBeTruthy();
  });
});
