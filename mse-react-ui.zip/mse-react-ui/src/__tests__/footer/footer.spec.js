import React from 'react';
import { cleanup, render } from '@testing-library/react';
import Footer from '../../core/footer/footer';

describe('Footer', () => {
  beforeEach(() => {
    cleanup();
  });

  it('should able to render app', () => {
    const app = render(<Footer />);
    expect(app).toBeTruthy();
  });
});
