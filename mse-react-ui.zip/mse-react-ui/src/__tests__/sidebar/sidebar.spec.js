import React from 'react';
import { cleanup, render } from '@testing-library/react';
import SidebarLayout from '../../core/sidebar/sidebar';

describe('SidebarLayout', () => {
  const sidebarContent = (
    <div>
      <a href="index.html">Home</a>
    </div>
  );
  beforeEach(() => {
    cleanup();
  });

  it('should able to render app', () => {
    const app = render(
      <SidebarLayout
        title="Sidebar"
        sidebarContent={sidebarContent}
        sidebarProps={{ docked: true, open: true }}
      >
        <div>Sidebar content</div>
      </SidebarLayout>
    );
    expect(app).toBeTruthy();
  });
});
