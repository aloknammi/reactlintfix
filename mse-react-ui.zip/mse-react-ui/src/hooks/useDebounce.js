import { useEffect, useState } from 'react';

 function UseDebounce (str, delayTime) {
  const [debouncedValue, setDebouncedValue] = useState(str);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(str);
    }, delayTime);
    return () => {
      clearTimeout(handler);
    };
  }, [str, delayTime]);

  return debouncedValue;
}

export default UseDebounce;
