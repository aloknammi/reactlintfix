import React from 'react';
import './footer.scss';

const Footer = () => (
  <footer className="page-footer font-small blue pt-4">
    <div className="footer-copyright text-center py-3">© Copyright 2022 Walgreen Co. 200 Wilmot Rd. Deerfield IL All rights reserved.</div>
  </footer>
);

export default Footer;
