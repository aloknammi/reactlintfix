import React from 'react';
import PropTypes from 'prop-types';
import Table from 'react-bootstrap/Table';

const TableContainer = (props) => {
  const { tableConfig, columns, rows } = props;
  return (
    <Table {...tableConfig}>
      <thead>
        <tr>
          {columns.map((header) => (
            <th key={header.id} {...header.th}>
              {header.title}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr key={row}>
            {Object.keys(row).map((r) => (
              <td key={r}>{row[r]}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </Table>
  );
};

TableContainer.propTypes = {
  tableConfig: PropTypes.any,
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      title: PropTypes.string,
      th: PropTypes.any
    })
  ),
  rows: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      label: PropTypes.string,
      td: PropTypes.any
    })
  )
};

export default TableContainer;
